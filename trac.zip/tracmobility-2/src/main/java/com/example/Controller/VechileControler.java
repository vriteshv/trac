package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Vechile;
import com.example.service.VechileRegisterService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
//it used for integration to application
@RestController
//it is used in spring web
@RequestMapping("/api/vechile")
//it will take n give input from url
public class VechileControler {
	
	@Autowired(required=true)
	VechileRegisterService vechileRegisterService;
	
	@PostMapping
	public Vechile createAccount(@RequestBody Vechile VechileRegsiter) {
		
		return vechileRegisterService.VechileRegistration(VechileRegsiter);
	}
	
	@GetMapping
	public List<Vechile> getAllAccounts(){
		return vechileRegisterService.viewAllVechiles();
	}

}
