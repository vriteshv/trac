package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.VechileRegisterDao;
import com.example.model.Vechile;

@Service 
public class VechileRegisterServiceImpl implements VechileRegisterService{

	@Autowired
	VechileRegisterDao vechileregisterdao;
	
	
	@Override
	public Vechile VechileRegistration(Vechile VechileRegsiter) {
		// TODO Auto-generated method stub
		return vechileregisterdao.save(VechileRegsiter);
	}

	@Override
	public List<Vechile> viewAllVechiles() {
		// TODO Auto-generated method stub
		return vechileregisterdao.findAll();
	}

}
