package com.example.service;

import java.util.List;

import com.example.model.Vechile;

public interface VechileRegisterService {
	
	public Vechile VechileRegistration(Vechile VechileRegsiter);
	
	public List<Vechile> viewAllVechiles();

}
