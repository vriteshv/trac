package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.print.attribute.standard.DateTimeAtCreation;


@Entity
//@Table(name = "vechile_register")
public class Vechile {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private long id;
	
	@Column
	private DateTimeAtCreation created_At;
	
	@Column
	private String vechile_Uuid;
	
	@Column
	private String qr_code;
	
	@Column
	private float lat;
	
	@Column
	private float lngg;
	
	//@Enumerated(EnumType.STRING)
	@Column
	private VechileStatus status;
	public enum VechileStatus
	{
		 active,
		 inactive,
		 running
		
	} 
	
	@Column
	private float battery_level;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public DateTimeAtCreation getCreated_At() {
		return created_At;
	}

	public void setCreated_At(DateTimeAtCreation created_At) {
		this.created_At = created_At;
	}

	public String getVechile_Uuid() {
		return vechile_Uuid;
	}

	public void setVechile_Uuid(String vechile_Uuid) {
		this.vechile_Uuid = vechile_Uuid;
	}

	public String getQr_code() {
		return qr_code;
	}

	public void setQr_code(String qr_code) {
		this.qr_code = qr_code;
	}

	public float getLat() {
		return lat;
	}

	public void setLat(float lat) {
		this.lat = lat;
	}

	public float getLngg() {
		return lngg;
	}

	public void setLngg(float lngg) {
		this.lngg = lngg;
	}

	public VechileStatus getStatus() {
		return status;
	}

	public void setStatus(VechileStatus status) {
		this.status = status;
	}

	public float getBattery_level() {
		return battery_level;
	}

	public void setBattery_level(float battery_level) {
		this.battery_level = battery_level;
	}

//	public Vechile(long id, DateTimeAtCreation created_At, String vechile_Uuid, String qr_code, float lat, float lngg,
//			VechileStatus status, float battery_level) {
//		super();
//		this.id = id;
//		this.created_At = created_At;
//		this.vechile_Uuid = vechile_Uuid;
//		this.qr_code = qr_code;
//		this.lat = lat;
//		this.lngg = lngg;
//		this.status = status;
//		this.battery_level = battery_level;
//	}

	@Override
	public String toString() {
		return "Vechile [id=" + id + ", created_At=" + created_At + ", vechile_Uuid=" + vechile_Uuid + ", qr_code="
				+ qr_code + ", lat=" + lat + ", lngg=" + lngg + ", status=" + status + ", battery_level="
				+ battery_level + "]";
	}
	
	
}
