package com.example.demoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tracmobility2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
